# Browser History Viewer

A comprehensive web-based tool for analyzing browser history databases from Chrome, Firefox, and Safari.

## Features

- **Multi-Browser Support**: Chrome, Firefox, and Safari SQLite databases
- **Web Interface**: Modern, responsive web UI
- **Drag & Drop**: Easy file upload with drag and drop functionality
- **Four Analysis Tabs**:
  - History Artifacts: Complete browsing history with visit counts
  - Downloads Artifacts: File download history and metadata
  - Visits Artifacts: Detailed visit information with transitions
  - Search Terms Artifacts: Search query history
- **Real-time Search**: Filter data across all tables
- **Professional UI**: Clean, modern interface with statistics

## Requirements

Create a `requirements.txt` file:

```
Flask==2.3.3
Werkzeug==2.3.7
```

## Installation & Setup

1. **Install Python dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Create the project structure**:
   ```
   browser_history_viewer/
   ├── app.py
   ├── templates/
   │   └── index.html
   ├── static/ (optional - for additional CSS/JS)
   └── requirements.txt
   ```

3. **Save the files**:
   - Save the Python code as `app.py`
   - Save the HTML code as `templates/index.html`

4. **Run the application**:
   ```bash
   python app.py
   ```

5. **Access the application**:
   Open your browser and go to `http://localhost:5000`

## Usage

### Finding Browser Database Files

**Chrome/Chromium**:
- Windows: `%LOCALAPPDATA%\Google\Chrome\User Data\Default\History`
- macOS: `~/Library/Application Support/Google/Chrome/Default/History`
- Linux: `~/.config/google-chrome/Default/History`

**Firefox**:
- Windows: `%APPDATA%\Mozilla\Firefox\Profiles\[profile]\places.sqlite`
- macOS: `~/Library/Application Support/Firefox/Profiles/[profile]/places.sqlite`
- Linux: `~/.mozilla/firefox/[profile]/places.sqlite`

**Safari**:
- macOS: `~/Library/Safari/History.db`

### Important Notes

1. **Close the browser** before copying database files, as they may be locked
2. **Make copies** of the database files rather than using the originals
3. **Privacy**: This tool processes data locally - no data is sent to external servers

### Using the Application

1. **Upload Database**: Drag and drop or browse for your `.sqlite` database file
2. **Browse Data**: Use the four tabs to explore different aspects of browser history
3. **Search**: Use the search boxes to filter data in each tab
4. **Export**: Data can be copied from tables or screenshots taken for documentation

## Database Schema Support

### Chrome
- `urls` table: Main history entries
- `visits` table: Individual visit records
- `downloads` table: Download history
- `keyword_search_terms` table: Search queries

### Firefox
- `moz_places` table: Main history entries
- `moz_historyvisits` table: Visit records
- `moz_annos` table: Annotations including downloads

### Safari
- `history_items` table: Main history entries
- `history_visits` table: Visit records

## Security Considerations

- Run the application locally only
- Don't share database files containing sensitive browsing data
- The Flask development server should not be used in production
- Consider the legal and ethical implications of analyzing browser history

## Troubleshooting

**"Database is locked" errors**:
- Ensure the browser is completely closed
- Copy the database file to a different location

**"Unknown browser type" errors**:
- Verify you're using the correct database file
- Some browsers may use different schemas

**Large database performance**:
- The tool limits some queries to improve performance
- Very large databases may take time to process

## Technical Details

- **Backend**: Python Flask application
- **Database**: SQLite3 with native Python sqlite3 module
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **File Handling**: Werkzeug secure filename handling
- **Timestamp Conversion**: Handles Chrome (WebKit), Firefox, and Safari timestamp formats

## License

This tool is for educational and forensic analysis purposes. Ensure you have proper authorization before analyzing browser databases that don't belong to you.